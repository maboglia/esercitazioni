<?php
include 'includes/functions.php';
include 'includes/session.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $events = load_events();
    $event = [
        'id' => generate_id($events),
        'title' => $_POST['title'],
        'date' => $_POST['date'],
        'description' => $_POST['description']
    ];
    $events[] = $event;
    save_events($events);
    increment_ops();
    flash('success', 'Evento aggiunto con successo!');
    header('Location: index.php');
    exit;
}

$event = [];
include 'includes/header.php';
include 'views/form.php';