<?php
include 'includes/functions.php';
include 'includes/session.php';

$id = $_GET['id'] ?? null;
$events = load_events();
$event = get_event_by_id($id);

if (!$event) {
    die("Evento non trovato.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    foreach ($events as &$e) {
        if ($e['id'] == $id) {
            $e['title'] = $_POST['title'];
            $e['date'] = $_POST['date'];
            $e['description'] = $_POST['description'];
            break;
        }
    }
    save_events($events);
    increment_ops();
    flash('success', 'Evento modificato con successo!');
    header('Location: index.php');
    exit;
}

include 'includes/header.php';
include 'views/form.php';