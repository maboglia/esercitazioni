<?php
// Includi funzioni e sessione
// Carica evento da modificare tramite ID in GET
// Se evento non trovato mostra errore
// Se form inviato:
//   - aggiorna i dati dell'evento
//   - salva eventi, incrementa operazioni, messaggio flash
//   - reindirizza
// Altrimenti mostra il form
