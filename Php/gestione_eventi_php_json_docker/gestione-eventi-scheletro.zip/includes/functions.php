<?php
// Scrivi funzioni per:
// - caricare gli eventi da un file JSON
// - salvare gli eventi su file JSON
// - generare un ID univoco per ogni evento
// - cercare un evento per ID
