<?php
// Includi il file di sessione
// Mostra intestazione HTML con nome utente e numero operazioni
// Includi link alla home e al form di aggiunta
