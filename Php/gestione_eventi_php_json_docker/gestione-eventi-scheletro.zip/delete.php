<?php
// Includi funzioni e sessione
// Carica eventi, cerca ID da eliminare
// Se trovato, rimuovi evento, salva, incrementa contatore, messaggio flash
// Reindirizza
