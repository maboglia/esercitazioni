<?php
// Includi la vista che mostra l'elenco degli eventi
