<?php
// Crea un form HTML per:
// - titolo (text, required)
// - data (date, required)
// - descrizione (textarea, required)
// Il form viene usato sia per aggiunta che modifica
