<?php
// Includi header e funzioni
// Carica gli eventi e mostra l'elenco in HTML
// Per ogni evento, mostra titolo, data, descrizione
// Aggiungi link a modifica ed elimina
